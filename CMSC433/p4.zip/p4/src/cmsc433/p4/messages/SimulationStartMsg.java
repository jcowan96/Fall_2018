package cmsc433.p4.messages;

/**
 * Class of messages used to tell simulation managers to start.
 * 
 * @author Rance Cleaveland
 *
 */
public class SimulationStartMsg {

}
