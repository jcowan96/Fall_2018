package cmsc433.p4.messages;


/**
 * Class of messages for starting user actors.
 * 
 * @author Rance Cleaveland
 *
 */
public class UserStartMsg {

}
